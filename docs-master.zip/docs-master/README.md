# Incode Internship Documents

This repo contains documents related Incode Internship program,
such as plans, methodology and etc.

## [Agenda](https://github.com/IncodeInternship/docs/blob/master/agenda.md)

## [User Story](https://github.com/IncodeInternship/docs/blob/master/user-story.md)

## [Pages mockups](https://github.com/IncodeInternship/docs/blob/master/mockups)
